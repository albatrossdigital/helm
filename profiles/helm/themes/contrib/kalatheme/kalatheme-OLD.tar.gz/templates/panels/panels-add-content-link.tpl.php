<?php
/**
 * @file
 * Template to control the add content individual links in the add content modal.
 */
?>
<?php print $button; ?>
